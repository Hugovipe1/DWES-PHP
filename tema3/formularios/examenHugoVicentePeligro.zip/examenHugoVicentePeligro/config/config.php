<?php
/**
 * @author Hugo Vicente Peligro
 */

const NUM_ABONADOS = 10;


$tarifas = array(
                array("equipo"=>"Picapiedras" ,"a"=> 12,"b"=> 22,"c"=> 32,"d"=> 42),
                array("equipo"=>"Roedores" ,"a"=> 13,"b"=> 23,"c"=> 33,"d"=> 43),
                array("equipo"=>"Perezosos" ,"a"=> 10,"b"=> 21,"c"=> 31,"d"=> 41),
                array("equipo"=>"Invisibles", "a"=> 14,"b"=> 24,"c"=> 34,"d"=> 44),
                array("equipo"=>"Legendarios", "a"=> 15,"b"=> 25,"c"=> 35,"d"=> 45),
                array("equipo"=>"Magos" ,"a"=> 10,"b"=> 20,"c"=> 38,"d"=> 40),
                array("equipo"=>"Sultanes", "a"=> 8,"b"=> 9,"c"=> 14,"d"=> 30),
            
            );
                



?>